﻿using MattEland.ResumeProcessor.Models;

namespace MattEland.ResumeProcessor.Logic
{
    public class ResumeScorer
    {
        public decimal EvaluateResumeForOpportunity(Resume resume, Opportunity opportunity)
        {
            return 0;
        }
    }
}
